(function(){

    
    let mensaje: string = 'Hola';
    let numero : number = 123;
    let booleano: boolean = true; // false
    let hoy: Date = new Date();


    let cualquiercosa;
    cualquiercosa = mensaje;
    cualquiercosa = numero;
    cualquiercosa = booleano;
    cualquiercosa = hoy;

    let spiderman = {
        nombre: 'Peter',
        edad: 30
    };
    
    spiderman = {
        nombre: 'Juan',
        edad: 40,
    };
    

    

})();



